# comdig_pract_BERTool

Se realiza un estudio que permtie:

- comprender la diferencia entre las modulaciones desde el punto de vista de la constelacion. Se asegura que el estudiante entiende qué son las constelaciones porque hasta las programa desde una tabla de verdad.
- comprender las ventajas y limitaciones de los diversos tipos de modulación, para lo cual se comienza con el estudio de la eficiencia espectral, sin ruido, donde todo parece ser maravilloso para las modulaciones de mayor orden.
- Finalmente se pasa al uso de ruido y estudio de BER y SER para llegar a entender las verdaderas posibles aplicaciones. Se incluye una herramienta propia de BERTool.

Enlace a la guia práctica: https://docs.google.com/document/d/1yBDJZx6hhy4XdBf79IRZi8nSf5HyI8WUZaYH5mxc0gc/edit?usp=sharing
