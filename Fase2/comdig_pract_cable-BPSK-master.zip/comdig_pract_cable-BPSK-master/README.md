# comdig_pract_cable-BPSK
Se trata de una práctica de laboratorio donde los estudiantes encuentran un sistema de comunicaciones basado en PCM con canal AWGN y con formador de pulsos y filtro de acoplamiento y derán adaptarlo para usar BPSK con USRPs unidos por cable.

INSTRUCCIONES:
Para realizar la práctica siga la guia en este enlace: https://docs.google.com/document/d/1Xq_HzgUDLNtFaw2Z-8GFr4Kq0iWA_HaAz46xIUQXm4M/edit?usp=sharing
